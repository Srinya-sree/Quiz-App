class AuthService {
  // Implement Firebase Auth login, signup here
}